Course Name: CS373: Software Engineering
Unique: 91055
First Name: Andy 
Last Name: Hsu
EID: ah28348
CS Username: andyhsu
GitHub ID: andyhsu91
GitHub Repository Name: cs373-collatz
Estimated number of hours: 20
Actual    number of hours: 24
Comments: None. Have fun.

I attest that I have written every line of code that I have submitted
and I take full responsibility for the origin of all the code submitted.
In particular, if any of the code was originally written in a previous
semester or another course I will so acknowledge via e-mail to the
grader.
